﻿using System;
using System.Windows.Forms;

namespace EAD_HW_2_Basic_Calculator
{
    public partial class Calculator : Form
    {
        //to keep record either last pressed operator is equal or not
        bool isEqualClicked = false;
        //to store first operand
        decimal inputNum1;
        //to store second operand
        decimal inputNum2;
        //to store the answer
        decimal outputNum;
        //to store first operand in form of string
        string charNum1;
        //to store second operand in form of string
        string charNum2;
        //to store operator
        char operatorr;
        //to store record of either an operator is pressed recently or not
        bool isOperatorPressed = false;
        public Calculator()
        {
            InitializeComponent();
        }

        //MC button is disabled
        private void MC_Click(object sender, EventArgs e)
        {

        }

        //sqrt button is disabled
        private void sqrt_Click(object sender, EventArgs e)
        {

        }

        //All menu items are disfunctional
        private void standardToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void programmerToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void historyToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void scientificToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void dateCalculationToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        //+- button is disabled
        private void plusMinus_Click(object sender, EventArgs e)
        {

        }

        //decimal point (.) is disabled
        private void button15_Click(object sender, EventArgs e)
        {

        }

        //% is disabled
        private void percentage_Click(object sender, EventArgs e)
        {

        }

        //M- is disabled
        private void Mminus_Click(object sender, EventArgs e)
        {

        }

        //M+ is disabled
        private void MPlus_Click(object sender, EventArgs e)
        {

        }

        //MS is disabled
        private void MS_Click(object sender, EventArgs e)
        {

        }

        //MR is disabled
        private void MR_Click(object sender, EventArgs e)
        {

        }

        //C is disabled
        private void C_Click(object sender, EventArgs e)
        {

        }

        //CE is disabled
        private void CE_Click(object sender, EventArgs e)
        {

        }

        //<-- is disabled
        private void BackArrow_Click(object sender, EventArgs e)
        {

        }

        //1/x is disabled
        private void OneByX_Click(object sender, EventArgs e)
        {

        }

        //this function resets the calculator if user completes a
        //calculation by pressing equal button and then presses a number
        //to start next calculation
        private void ResetCalculator()
        {
            //if equal is clicked recently, reset the calculator
            if (isEqualClicked)
            {
                InputTextBox.Text ="";//reset the input text box
                inputNum1 = 0;//reset the operands
                inputNum2 = 0;
                isEqualClicked=false;
                isOperatorPressed=false;
                charNum1="";//reset the string for of operands
                charNum2="";
                operatorr='\0';//reset the operator
            }
            //else do nothing
        }

        //this function converts the string form of operands to 
        //original decimal operands
        private void GetOperands()
        {
            if (charNum1=="")
            {
                inputNum1=0;
            }
            else
            {
                inputNum1=Convert.ToDecimal(charNum1);
            }

            if (charNum2=="")
            {
                inputNum2=0;
            }
            else
            {
                inputNum2=Convert.ToDecimal(charNum2);
            }
        }

        //this function performs the current operation (operator) 
        //on current operands
        private void PerformOperation()
        {
            switch(operatorr)
            {
                case '+':
                    {
                        outputNum=inputNum1+ inputNum2;
                        break;
                    }
                case '-':
                    {
                        outputNum=inputNum1-inputNum2;
                        break;
                    }
                case '*':
                    {
                        outputNum=inputNum1*inputNum2;
                        break;
                    }
                case '/':
                    {
                        outputNum=inputNum1/inputNum2;
                        break;
                    }
                default:
                    {
                        break;
                    }
            }
        }

        private void one_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new
            //calculation is going to start. And we will get this if we 
            //get either equal is pressed or not, call reset
            //calculator to reset the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='1';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='1';
            }
            else
            {
                charNum1+='1';
            }
        }

        private void two_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='2';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='2';
            }
            else
            {
                charNum1+='2';
            }
        }

        private void three_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='3';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='3';
            }
            else
            {
                charNum1+='3';
            }
        }

        private void four_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='4';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='4';
            }
            else
            {
                charNum1+='4';
            }
        }

        private void five_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='5';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='5';
            }
            else
            {
                charNum1+='5';
            }
        }

        private void six_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='6';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='6';
            }
            else
            {
                charNum1+='6';
            }
        }

        private void seven_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='7';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='7';
            }
            else
            {
                charNum1+='7';
            }
        }

        private void eight_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='8';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='8';
            }
            else
            {
                charNum1+='8';
            }
        }

        private void nine_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='9';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='9';
            }
            else
            {
                charNum1+='9';
            }
        }

        private void zero_Click(object sender, EventArgs e)
        {
            //if a number is clicked,

            //1-----
            //check if a new calculation is going to start.
            //And we will get this if we get either equal is
            //pressed or not, call reset calculator to reset
            //the calculator if the equal is pressed.
            ResetCalculator();
            //2------
            //write number in the input field
            InputTextBox.Text +='0';
            //3-----
            //if an operator is entered before,
            //update num2 to this entered num
            if (isOperatorPressed)
            {
                charNum2+='0';
            }
            else
            {
                charNum1+='0';
            }
        }

        private void plus_Click(object sender, EventArgs e)
        {
            //if = is the latest pressed operator
            if (isEqualClicked)
            {
                //then 
                isEqualClicked = false;
                charNum1 = OutputTextBox.Text;//store the latest output in string form of operand 1
                isOperatorPressed = true;
                operatorr = '+';
                InputTextBox.Text = $"{charNum1}{operatorr}";//update input field with the latest output plus the latest operand pressed
            }
            //if no operator is pressed so far after the latest click is pressed 
            else if (!isOperatorPressed)
            {
                //then
                isOperatorPressed = true;
                operatorr = '+';
                InputTextBox.Text += "+";
            }
            else
            {
                GetOperands();//sets the operands
                PerformOperation();//calculates the result
                OutputTextBox.Text =    $"{outputNum}";//updates output field
                inputNum1=outputNum;//updates first operand to the latest output (getting ready for next calc)
                inputNum2=0;//second operand to zero
                charNum1=$"{outputNum}";
                charNum2="";

                operatorr = '+';
                charNum1 = OutputTextBox.Text;
                InputTextBox.Text = $"{charNum1}{operatorr}";//updates input field to the first operand plus latest operator
            }
        }


        //not commenting it because it functions same as the plus operator wala function 
        private void minus_Click(object sender, EventArgs e)
        {
            if (isEqualClicked)
            {
                isEqualClicked = false;
                charNum1 = OutputTextBox.Text;
                isOperatorPressed = true;
                operatorr = '-';
                InputTextBox.Text = $"{charNum1}{operatorr}";
            }
            else if (!isOperatorPressed)
            {
                isOperatorPressed = true;
                operatorr = '-';
                InputTextBox.Text += "-";
            }
            else
            {
                GetOperands();
                PerformOperation();
                OutputTextBox.Text =    $"{outputNum}";
                inputNum1=outputNum;
                inputNum2=0;
                charNum1=$"{outputNum}";
                charNum2="";

                operatorr = '-';
                charNum1 = OutputTextBox.Text;
                InputTextBox.Text = $"{charNum1}{operatorr}";
            }
        }


        //not commenting it because it functions same as the plus operator wala function 
        private void multiply_Click(object sender, EventArgs e)
        {
            if (isEqualClicked)
            {
                isEqualClicked = false;
                charNum1 = OutputTextBox.Text;
                isOperatorPressed = true;
                operatorr = '*';
                InputTextBox.Text = $"{charNum1}{operatorr}";
            }
            else if (!isOperatorPressed)
            {
                isOperatorPressed = true;
                operatorr = '*';
                InputTextBox.Text += "*";
            }
            else
            {
                GetOperands();
                PerformOperation();
                OutputTextBox.Text =    $"{outputNum}";
                inputNum1=outputNum;
                inputNum2=0;
                charNum1=$"{outputNum}";
                charNum2="";

                operatorr = '*';
                charNum1 = OutputTextBox.Text;
                InputTextBox.Text = $"{charNum1}{operatorr}";
            }
        }


        //not commenting it because it functions same as the plus operator wala function 
        private void divide_Click(object sender, EventArgs e)
        {
            if (isEqualClicked)
            {
                isEqualClicked = false;
                charNum1 = OutputTextBox.Text;
                isOperatorPressed = true;
                operatorr = '/';
                InputTextBox.Text = $"{charNum1}{operatorr}";
            }
            else if (!isOperatorPressed)
            {
                isOperatorPressed = true;
                operatorr = '/';
                InputTextBox.Text += "/";
            }
            else
            {
                GetOperands();
                PerformOperation();
                OutputTextBox.Text =    $"{outputNum}";
                inputNum1=outputNum;
                inputNum2=0;
                charNum1=$"{outputNum}";
                charNum2="";

                operatorr = '/';
                charNum1 = OutputTextBox.Text;
                InputTextBox.Text = $"{charNum1}{operatorr}";
            }
        }

        private void Equal_Click(object sender, EventArgs e)
        {
            isEqualClicked=true;
            GetOperands();
            PerformOperation();
            OutputTextBox.Text =    $"{outputNum}";
            inputNum1=outputNum;
            inputNum2=0;
            charNum1=$"{outputNum}";
            charNum2="";
        }
    }
}
