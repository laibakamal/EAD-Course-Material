﻿namespace EAD_HW_2_Basic_Calculator
{
    partial class Calculator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.tableLayoutPanel1 = new System.Windows.Forms.TableLayoutPanel();
            this.plus = new System.Windows.Forms.Button();
            this.decimalPoint = new System.Windows.Forms.Button();
            this.two = new System.Windows.Forms.Button();
            this.one = new System.Windows.Forms.Button();
            this.OneByX = new System.Windows.Forms.Button();
            this.percentage = new System.Windows.Forms.Button();
            this.eight = new System.Windows.Forms.Button();
            this.MC = new System.Windows.Forms.Button();
            this.MR = new System.Windows.Forms.Button();
            this.MS = new System.Windows.Forms.Button();
            this.MPlus = new System.Windows.Forms.Button();
            this.Mminus = new System.Windows.Forms.Button();
            this.Equal = new System.Windows.Forms.Button();
            this.BackArrow = new System.Windows.Forms.Button();
            this.CE = new System.Windows.Forms.Button();
            this.C = new System.Windows.Forms.Button();
            this.plusMinus = new System.Windows.Forms.Button();
            this.sqrt = new System.Windows.Forms.Button();
            this.seven = new System.Windows.Forms.Button();
            this.three = new System.Windows.Forms.Button();
            this.four = new System.Windows.Forms.Button();
            this.six = new System.Windows.Forms.Button();
            this.minus = new System.Windows.Forms.Button();
            this.five = new System.Windows.Forms.Button();
            this.nine = new System.Windows.Forms.Button();
            this.zero = new System.Windows.Forms.Button();
            this.multiply = new System.Windows.Forms.Button();
            this.divide = new System.Windows.Forms.Button();
            this.InputTextBox = new System.Windows.Forms.TextBox();
            this.OutputTextBox = new System.Windows.Forms.TextBox();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.viewToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.standardToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.scientificToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.programmerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.statisticsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.digitGroupingToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.basicToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.unitConversionToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.dateCalculationToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.worksheetsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.editToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.copyCtrlCToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.pasteCtrlVToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.historyToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.viewHelpF1ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.aboutCalculatorToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.tableLayoutPanel1.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // tableLayoutPanel1
            // 
            this.tableLayoutPanel1.ColumnCount = 5;
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 49.48454F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 50.51546F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 47F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 48F));
            this.tableLayoutPanel1.ColumnStyles.Add(new System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Absolute, 53F));
            this.tableLayoutPanel1.Controls.Add(this.plus, 3, 5);
            this.tableLayoutPanel1.Controls.Add(this.decimalPoint, 2, 5);
            this.tableLayoutPanel1.Controls.Add(this.two, 1, 4);
            this.tableLayoutPanel1.Controls.Add(this.one, 0, 4);
            this.tableLayoutPanel1.Controls.Add(this.OneByX, 4, 3);
            this.tableLayoutPanel1.Controls.Add(this.percentage, 4, 2);
            this.tableLayoutPanel1.Controls.Add(this.eight, 1, 2);
            this.tableLayoutPanel1.Controls.Add(this.MC, 0, 0);
            this.tableLayoutPanel1.Controls.Add(this.MR, 1, 0);
            this.tableLayoutPanel1.Controls.Add(this.MS, 2, 0);
            this.tableLayoutPanel1.Controls.Add(this.MPlus, 3, 0);
            this.tableLayoutPanel1.Controls.Add(this.Mminus, 4, 0);
            this.tableLayoutPanel1.Controls.Add(this.Equal, 4, 4);
            this.tableLayoutPanel1.Controls.Add(this.BackArrow, 0, 1);
            this.tableLayoutPanel1.Controls.Add(this.CE, 1, 1);
            this.tableLayoutPanel1.Controls.Add(this.C, 2, 1);
            this.tableLayoutPanel1.Controls.Add(this.plusMinus, 3, 1);
            this.tableLayoutPanel1.Controls.Add(this.sqrt, 4, 1);
            this.tableLayoutPanel1.Controls.Add(this.seven, 0, 2);
            this.tableLayoutPanel1.Controls.Add(this.three, 2, 4);
            this.tableLayoutPanel1.Controls.Add(this.four, 0, 3);
            this.tableLayoutPanel1.Controls.Add(this.six, 2, 3);
            this.tableLayoutPanel1.Controls.Add(this.minus, 3, 4);
            this.tableLayoutPanel1.Controls.Add(this.five, 1, 3);
            this.tableLayoutPanel1.Controls.Add(this.nine, 2, 2);
            this.tableLayoutPanel1.Controls.Add(this.zero, 0, 5);
            this.tableLayoutPanel1.Controls.Add(this.multiply, 3, 3);
            this.tableLayoutPanel1.Controls.Add(this.divide, 3, 2);
            this.tableLayoutPanel1.Location = new System.Drawing.Point(12, 91);
            this.tableLayoutPanel1.Name = "tableLayoutPanel1";
            this.tableLayoutPanel1.RowCount = 6;
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 50.70422F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 49.29578F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 36F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 34F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 35F));
            this.tableLayoutPanel1.RowStyles.Add(new System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Absolute, 32F));
            this.tableLayoutPanel1.Size = new System.Drawing.Size(242, 209);
            this.tableLayoutPanel1.TabIndex = 5;
            // 
            // plus
            // 
            this.plus.BackColor = System.Drawing.SystemColors.Window;
            this.plus.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.plus.Location = new System.Drawing.Point(143, 179);
            this.plus.Name = "plus";
            this.plus.Size = new System.Drawing.Size(42, 27);
            this.plus.TabIndex = 33;
            this.plus.Text = "+";
            this.plus.UseVisualStyleBackColor = false;
            this.plus.Click += new System.EventHandler(this.plus_Click);
            // 
            // decimalPoint
            // 
            this.decimalPoint.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.decimalPoint.Enabled = false;
            this.decimalPoint.Font = new System.Drawing.Font("Microsoft YaHei UI", 11F, System.Drawing.FontStyle.Bold);
            this.decimalPoint.Location = new System.Drawing.Point(96, 179);
            this.decimalPoint.Name = "decimalPoint";
            this.decimalPoint.Size = new System.Drawing.Size(41, 27);
            this.decimalPoint.TabIndex = 32;
            this.decimalPoint.Text = ".";
            this.decimalPoint.UseVisualStyleBackColor = false;
            this.decimalPoint.Click += new System.EventHandler(this.button15_Click);
            // 
            // two
            // 
            this.two.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.two.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.two.Location = new System.Drawing.Point(49, 144);
            this.two.Name = "two";
            this.two.Size = new System.Drawing.Size(41, 29);
            this.two.TabIndex = 28;
            this.two.Text = "2";
            this.two.UseVisualStyleBackColor = false;
            this.two.Click += new System.EventHandler(this.two_Click);
            // 
            // one
            // 
            this.one.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.one.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.one.Location = new System.Drawing.Point(3, 144);
            this.one.Name = "one";
            this.one.Size = new System.Drawing.Size(40, 29);
            this.one.TabIndex = 27;
            this.one.Text = "1";
            this.one.UseVisualStyleBackColor = false;
            this.one.Click += new System.EventHandler(this.one_Click);
            // 
            // OneByX
            // 
            this.OneByX.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.OneByX.Enabled = false;
            this.OneByX.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.OneByX.Location = new System.Drawing.Point(191, 110);
            this.OneByX.Name = "OneByX";
            this.OneByX.Size = new System.Drawing.Size(44, 28);
            this.OneByX.TabIndex = 26;
            this.OneByX.Text = "1/x";
            this.OneByX.UseVisualStyleBackColor = false;
            this.OneByX.Click += new System.EventHandler(this.OneByX_Click);
            // 
            // percentage
            // 
            this.percentage.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.percentage.Enabled = false;
            this.percentage.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.percentage.Location = new System.Drawing.Point(191, 74);
            this.percentage.Name = "percentage";
            this.percentage.Size = new System.Drawing.Size(44, 28);
            this.percentage.TabIndex = 21;
            this.percentage.Text = "%";
            this.percentage.UseVisualStyleBackColor = false;
            this.percentage.Click += new System.EventHandler(this.percentage_Click);
            // 
            // eight
            // 
            this.eight.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.eight.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.eight.Location = new System.Drawing.Point(49, 74);
            this.eight.Name = "eight";
            this.eight.Size = new System.Drawing.Size(41, 30);
            this.eight.TabIndex = 18;
            this.eight.Text = "8";
            this.eight.UseVisualStyleBackColor = false;
            this.eight.Click += new System.EventHandler(this.eight_Click);
            // 
            // MC
            // 
            this.MC.BackColor = System.Drawing.SystemColors.Window;
            this.MC.Enabled = false;
            this.MC.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.MC.Location = new System.Drawing.Point(3, 3);
            this.MC.Name = "MC";
            this.MC.Size = new System.Drawing.Size(40, 30);
            this.MC.TabIndex = 6;
            this.MC.Text = "MC";
            this.MC.UseVisualStyleBackColor = false;
            this.MC.Click += new System.EventHandler(this.MC_Click);
            // 
            // MR
            // 
            this.MR.BackColor = System.Drawing.SystemColors.Window;
            this.MR.Enabled = false;
            this.MR.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.MR.Location = new System.Drawing.Point(49, 3);
            this.MR.Name = "MR";
            this.MR.Size = new System.Drawing.Size(41, 30);
            this.MR.TabIndex = 7;
            this.MR.Text = "MR";
            this.MR.UseVisualStyleBackColor = false;
            this.MR.Click += new System.EventHandler(this.MR_Click);
            // 
            // MS
            // 
            this.MS.BackColor = System.Drawing.SystemColors.Window;
            this.MS.Enabled = false;
            this.MS.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.MS.Location = new System.Drawing.Point(96, 3);
            this.MS.Name = "MS";
            this.MS.Size = new System.Drawing.Size(41, 30);
            this.MS.TabIndex = 8;
            this.MS.Text = "MS";
            this.MS.UseVisualStyleBackColor = false;
            this.MS.Click += new System.EventHandler(this.MS_Click);
            // 
            // MPlus
            // 
            this.MPlus.BackColor = System.Drawing.SystemColors.Window;
            this.MPlus.Enabled = false;
            this.MPlus.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.MPlus.Location = new System.Drawing.Point(143, 3);
            this.MPlus.Name = "MPlus";
            this.MPlus.Size = new System.Drawing.Size(42, 30);
            this.MPlus.TabIndex = 9;
            this.MPlus.Text = "M+";
            this.MPlus.UseVisualStyleBackColor = false;
            this.MPlus.Click += new System.EventHandler(this.MPlus_Click);
            // 
            // Mminus
            // 
            this.Mminus.BackColor = System.Drawing.SystemColors.Window;
            this.Mminus.Enabled = false;
            this.Mminus.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.Mminus.Location = new System.Drawing.Point(191, 3);
            this.Mminus.Name = "Mminus";
            this.Mminus.Size = new System.Drawing.Size(44, 30);
            this.Mminus.TabIndex = 10;
            this.Mminus.Text = "M-";
            this.Mminus.UseVisualStyleBackColor = false;
            this.Mminus.Click += new System.EventHandler(this.Mminus_Click);
            // 
            // Equal
            // 
            this.Equal.BackColor = System.Drawing.SystemColors.Window;
            this.Equal.Font = new System.Drawing.Font("Microsoft YaHei UI", 15F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Equal.Location = new System.Drawing.Point(191, 144);
            this.Equal.Name = "Equal";
            this.tableLayoutPanel1.SetRowSpan(this.Equal, 2);
            this.Equal.Size = new System.Drawing.Size(41, 62);
            this.Equal.TabIndex = 11;
            this.Equal.Text = "=";
            this.Equal.UseVisualStyleBackColor = false;
            this.Equal.Click += new System.EventHandler(this.Equal_Click);
            // 
            // BackArrow
            // 
            this.BackArrow.BackColor = System.Drawing.SystemColors.Window;
            this.BackArrow.Enabled = false;
            this.BackArrow.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.BackArrow.Location = new System.Drawing.Point(3, 39);
            this.BackArrow.Name = "BackArrow";
            this.BackArrow.Size = new System.Drawing.Size(40, 29);
            this.BackArrow.TabIndex = 12;
            this.BackArrow.Text = "<--";
            this.BackArrow.UseVisualStyleBackColor = false;
            this.BackArrow.Click += new System.EventHandler(this.BackArrow_Click);
            // 
            // CE
            // 
            this.CE.BackColor = System.Drawing.SystemColors.Window;
            this.CE.Enabled = false;
            this.CE.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.CE.Location = new System.Drawing.Point(49, 39);
            this.CE.Name = "CE";
            this.CE.Size = new System.Drawing.Size(40, 29);
            this.CE.TabIndex = 13;
            this.CE.Text = "CE";
            this.CE.UseVisualStyleBackColor = false;
            this.CE.Click += new System.EventHandler(this.CE_Click);
            // 
            // C
            // 
            this.C.BackColor = System.Drawing.SystemColors.Window;
            this.C.Enabled = false;
            this.C.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.C.Location = new System.Drawing.Point(96, 39);
            this.C.Name = "C";
            this.C.Size = new System.Drawing.Size(41, 29);
            this.C.TabIndex = 14;
            this.C.Text = "C";
            this.C.UseVisualStyleBackColor = false;
            this.C.Click += new System.EventHandler(this.C_Click);
            // 
            // plusMinus
            // 
            this.plusMinus.BackColor = System.Drawing.SystemColors.Window;
            this.plusMinus.Enabled = false;
            this.plusMinus.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.plusMinus.Location = new System.Drawing.Point(143, 39);
            this.plusMinus.Name = "plusMinus";
            this.plusMinus.Size = new System.Drawing.Size(42, 29);
            this.plusMinus.TabIndex = 15;
            this.plusMinus.Text = "+-";
            this.plusMinus.UseVisualStyleBackColor = false;
            this.plusMinus.Click += new System.EventHandler(this.plusMinus_Click);
            // 
            // sqrt
            // 
            this.sqrt.BackColor = System.Drawing.SystemColors.Window;
            this.sqrt.Enabled = false;
            this.sqrt.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.sqrt.Location = new System.Drawing.Point(191, 39);
            this.sqrt.Name = "sqrt";
            this.sqrt.Size = new System.Drawing.Size(44, 29);
            this.sqrt.TabIndex = 16;
            this.sqrt.Text = "sqrt";
            this.sqrt.UseVisualStyleBackColor = false;
            this.sqrt.Click += new System.EventHandler(this.sqrt_Click);
            // 
            // seven
            // 
            this.seven.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.seven.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.seven.Location = new System.Drawing.Point(3, 74);
            this.seven.Name = "seven";
            this.seven.Size = new System.Drawing.Size(40, 28);
            this.seven.TabIndex = 17;
            this.seven.Text = "7";
            this.seven.UseVisualStyleBackColor = false;
            this.seven.Click += new System.EventHandler(this.seven_Click);
            // 
            // three
            // 
            this.three.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.three.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.three.Location = new System.Drawing.Point(96, 144);
            this.three.Name = "three";
            this.three.Size = new System.Drawing.Size(41, 29);
            this.three.TabIndex = 29;
            this.three.Text = "3";
            this.three.UseVisualStyleBackColor = false;
            this.three.Click += new System.EventHandler(this.three_Click);
            // 
            // four
            // 
            this.four.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.four.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.four.Location = new System.Drawing.Point(3, 110);
            this.four.Name = "four";
            this.four.Size = new System.Drawing.Size(40, 28);
            this.four.TabIndex = 22;
            this.four.Text = "4";
            this.four.UseVisualStyleBackColor = false;
            this.four.Click += new System.EventHandler(this.four_Click);
            // 
            // six
            // 
            this.six.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.six.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.six.Location = new System.Drawing.Point(96, 110);
            this.six.Name = "six";
            this.six.Size = new System.Drawing.Size(41, 28);
            this.six.TabIndex = 24;
            this.six.Text = "6";
            this.six.UseVisualStyleBackColor = false;
            this.six.Click += new System.EventHandler(this.six_Click);
            // 
            // minus
            // 
            this.minus.BackColor = System.Drawing.SystemColors.Window;
            this.minus.Font = new System.Drawing.Font("Microsoft YaHei UI Light", 14F);
            this.minus.Location = new System.Drawing.Point(143, 144);
            this.minus.Name = "minus";
            this.minus.Size = new System.Drawing.Size(42, 29);
            this.minus.TabIndex = 30;
            this.minus.Text = "-";
            this.minus.UseVisualStyleBackColor = false;
            this.minus.Click += new System.EventHandler(this.minus_Click);
            // 
            // five
            // 
            this.five.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.five.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.five.Location = new System.Drawing.Point(49, 110);
            this.five.Name = "five";
            this.five.Size = new System.Drawing.Size(41, 28);
            this.five.TabIndex = 34;
            this.five.Text = "5";
            this.five.UseVisualStyleBackColor = false;
            this.five.Click += new System.EventHandler(this.five_Click);
            // 
            // nine
            // 
            this.nine.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.nine.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.nine.Location = new System.Drawing.Point(96, 74);
            this.nine.Name = "nine";
            this.nine.Size = new System.Drawing.Size(41, 30);
            this.nine.TabIndex = 35;
            this.nine.Text = "9";
            this.nine.UseVisualStyleBackColor = false;
            this.nine.Click += new System.EventHandler(this.nine_Click);
            // 
            // zero
            // 
            this.zero.BackColor = System.Drawing.SystemColors.GradientActiveCaption;
            this.tableLayoutPanel1.SetColumnSpan(this.zero, 2);
            this.zero.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.zero.Location = new System.Drawing.Point(3, 179);
            this.zero.Name = "zero";
            this.zero.Size = new System.Drawing.Size(87, 27);
            this.zero.TabIndex = 36;
            this.zero.Text = "0";
            this.zero.UseVisualStyleBackColor = false;
            this.zero.Click += new System.EventHandler(this.zero_Click);
            // 
            // multiply
            // 
            this.multiply.BackColor = System.Drawing.SystemColors.Window;
            this.multiply.Font = new System.Drawing.Font("Microsoft YaHei UI", 15F);
            this.multiply.Location = new System.Drawing.Point(143, 110);
            this.multiply.Name = "multiply";
            this.multiply.Size = new System.Drawing.Size(42, 28);
            this.multiply.TabIndex = 38;
            this.multiply.Text = "*";
            this.multiply.UseVisualStyleBackColor = false;
            this.multiply.Click += new System.EventHandler(this.multiply_Click);
            // 
            // divide
            // 
            this.divide.BackColor = System.Drawing.SystemColors.Window;
            this.divide.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F);
            this.divide.Location = new System.Drawing.Point(143, 74);
            this.divide.Name = "divide";
            this.divide.Size = new System.Drawing.Size(42, 30);
            this.divide.TabIndex = 39;
            this.divide.Text = "/";
            this.divide.UseVisualStyleBackColor = false;
            this.divide.Click += new System.EventHandler(this.divide_Click);
            // 
            // InputTextBox
            // 
            this.InputTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.InputTextBox.Location = new System.Drawing.Point(15, 27);
            this.InputTextBox.Multiline = true;
            this.InputTextBox.Name = "InputTextBox";
            this.InputTextBox.ReadOnly = true;
            this.InputTextBox.Size = new System.Drawing.Size(239, 26);
            this.InputTextBox.TabIndex = 7;
            // 
            // OutputTextBox
            // 
            this.OutputTextBox.BorderStyle = System.Windows.Forms.BorderStyle.None;
            this.OutputTextBox.Location = new System.Drawing.Point(15, 52);
            this.OutputTextBox.Multiline = true;
            this.OutputTextBox.Name = "OutputTextBox";
            this.OutputTextBox.ReadOnly = true;
            this.OutputTextBox.Size = new System.Drawing.Size(239, 27);
            this.OutputTextBox.TabIndex = 8;
            // 
            // menuStrip1
            // 
            this.menuStrip1.BackColor = System.Drawing.SystemColors.InactiveCaption;
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewToolStripMenuItem,
            this.editToolStripMenuItem,
            this.helpToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.RenderMode = System.Windows.Forms.ToolStripRenderMode.System;
            this.menuStrip1.Size = new System.Drawing.Size(266, 24);
            this.menuStrip1.TabIndex = 9;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // viewToolStripMenuItem
            // 
            this.viewToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.standardToolStripMenuItem,
            this.scientificToolStripMenuItem,
            this.programmerToolStripMenuItem,
            this.statisticsToolStripMenuItem,
            this.historyToolStripMenuItem,
            this.digitGroupingToolStripMenuItem,
            this.basicToolStripMenuItem,
            this.unitConversionToolStripMenuItem,
            this.dateCalculationToolStripMenuItem,
            this.worksheetsToolStripMenuItem});
            this.viewToolStripMenuItem.Name = "viewToolStripMenuItem";
            this.viewToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.viewToolStripMenuItem.Text = "View";
            // 
            // standardToolStripMenuItem
            // 
            this.standardToolStripMenuItem.Name = "standardToolStripMenuItem";
            this.standardToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.standardToolStripMenuItem.Text = "Standard                      Alt+1";
            this.standardToolStripMenuItem.Click += new System.EventHandler(this.standardToolStripMenuItem_Click);
            // 
            // scientificToolStripMenuItem
            // 
            this.scientificToolStripMenuItem.Name = "scientificToolStripMenuItem";
            this.scientificToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.scientificToolStripMenuItem.Text = "Scientific                     Alt+2";
            this.scientificToolStripMenuItem.Click += new System.EventHandler(this.scientificToolStripMenuItem_Click);
            // 
            // programmerToolStripMenuItem
            // 
            this.programmerToolStripMenuItem.Name = "programmerToolStripMenuItem";
            this.programmerToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.programmerToolStripMenuItem.Text = "Programmer               Alt+3";
            this.programmerToolStripMenuItem.Click += new System.EventHandler(this.programmerToolStripMenuItem_Click);
            // 
            // statisticsToolStripMenuItem
            // 
            this.statisticsToolStripMenuItem.Name = "statisticsToolStripMenuItem";
            this.statisticsToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.statisticsToolStripMenuItem.Text = "Statistics                     Alt+4";
            // 
            // historyToolStripMenuItem
            // 
            this.historyToolStripMenuItem.Name = "historyToolStripMenuItem";
            this.historyToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.historyToolStripMenuItem.Text = "History                        Ctrl+H";
            this.historyToolStripMenuItem.Click += new System.EventHandler(this.historyToolStripMenuItem_Click);
            // 
            // digitGroupingToolStripMenuItem
            // 
            this.digitGroupingToolStripMenuItem.Name = "digitGroupingToolStripMenuItem";
            this.digitGroupingToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.digitGroupingToolStripMenuItem.Text = "Digit Grouping";
            // 
            // basicToolStripMenuItem
            // 
            this.basicToolStripMenuItem.Name = "basicToolStripMenuItem";
            this.basicToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.basicToolStripMenuItem.Text = "Basic                            Ctrl+F4";
            // 
            // unitConversionToolStripMenuItem
            // 
            this.unitConversionToolStripMenuItem.Name = "unitConversionToolStripMenuItem";
            this.unitConversionToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.unitConversionToolStripMenuItem.Text = "Unit Conversion           Ctrl+U";
            // 
            // dateCalculationToolStripMenuItem
            // 
            this.dateCalculationToolStripMenuItem.Name = "dateCalculationToolStripMenuItem";
            this.dateCalculationToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.dateCalculationToolStripMenuItem.Text = "Date Calculation          Ctrl+E";
            this.dateCalculationToolStripMenuItem.Click += new System.EventHandler(this.dateCalculationToolStripMenuItem_Click);
            // 
            // worksheetsToolStripMenuItem
            // 
            this.worksheetsToolStripMenuItem.Name = "worksheetsToolStripMenuItem";
            this.worksheetsToolStripMenuItem.Size = new System.Drawing.Size(227, 22);
            this.worksheetsToolStripMenuItem.Text = "Worksheets";
            // 
            // editToolStripMenuItem
            // 
            this.editToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.copyCtrlCToolStripMenuItem,
            this.pasteCtrlVToolStripMenuItem,
            this.historyToolStripMenuItem1});
            this.editToolStripMenuItem.Name = "editToolStripMenuItem";
            this.editToolStripMenuItem.Size = new System.Drawing.Size(39, 20);
            this.editToolStripMenuItem.Text = "Edit";
            // 
            // copyCtrlCToolStripMenuItem
            // 
            this.copyCtrlCToolStripMenuItem.Name = "copyCtrlCToolStripMenuItem";
            this.copyCtrlCToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.copyCtrlCToolStripMenuItem.Text = "Copy        Ctrl+C";
            // 
            // pasteCtrlVToolStripMenuItem
            // 
            this.pasteCtrlVToolStripMenuItem.Enabled = false;
            this.pasteCtrlVToolStripMenuItem.Name = "pasteCtrlVToolStripMenuItem";
            this.pasteCtrlVToolStripMenuItem.Size = new System.Drawing.Size(163, 22);
            this.pasteCtrlVToolStripMenuItem.Text = "Paste         Ctrl+V";
            // 
            // historyToolStripMenuItem1
            // 
            this.historyToolStripMenuItem1.Name = "historyToolStripMenuItem1";
            this.historyToolStripMenuItem1.Size = new System.Drawing.Size(163, 22);
            this.historyToolStripMenuItem1.Text = "History";
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.viewHelpF1ToolStripMenuItem,
            this.aboutCalculatorToolStripMenuItem});
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(44, 20);
            this.helpToolStripMenuItem.Text = "Help";
            // 
            // viewHelpF1ToolStripMenuItem
            // 
            this.viewHelpF1ToolStripMenuItem.Name = "viewHelpF1ToolStripMenuItem";
            this.viewHelpF1ToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.viewHelpF1ToolStripMenuItem.Text = "View Help              F1";
            // 
            // aboutCalculatorToolStripMenuItem
            // 
            this.aboutCalculatorToolStripMenuItem.Name = "aboutCalculatorToolStripMenuItem";
            this.aboutCalculatorToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.aboutCalculatorToolStripMenuItem.Text = "About Calculator";
            // 
            // Calculator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.ScrollBar;
            this.ClientSize = new System.Drawing.Size(266, 308);
            this.Controls.Add(this.OutputTextBox);
            this.Controls.Add(this.InputTextBox);
            this.Controls.Add(this.tableLayoutPanel1);
            this.Controls.Add(this.menuStrip1);
            this.Font = new System.Drawing.Font("Microsoft YaHei UI", 10F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
            this.HelpButton = true;
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(5, 4, 5, 4);
            this.Name = "Calculator";
            this.Text = "Calculator";
            this.tableLayoutPanel1.ResumeLayout(false);
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TableLayoutPanel tableLayoutPanel1;
        private System.Windows.Forms.Button MC;
        private System.Windows.Forms.Button MR;
        private System.Windows.Forms.Button MS;
        private System.Windows.Forms.Button MPlus;
        private System.Windows.Forms.Button Mminus;
        private System.Windows.Forms.Button Equal;
        private System.Windows.Forms.Button BackArrow;
        private System.Windows.Forms.Button CE;
        private System.Windows.Forms.Button C;
        private System.Windows.Forms.Button plusMinus;
        private System.Windows.Forms.Button sqrt;
        private System.Windows.Forms.Button eight;
        private System.Windows.Forms.Button seven;
        private System.Windows.Forms.Button percentage;
        private System.Windows.Forms.Button three;
        private System.Windows.Forms.Button two;
        private System.Windows.Forms.Button one;
        private System.Windows.Forms.Button OneByX;
        private System.Windows.Forms.Button six;
        private System.Windows.Forms.Button four;
        private System.Windows.Forms.Button minus;
        private System.Windows.Forms.Button plus;
        private System.Windows.Forms.Button decimalPoint;
        private System.Windows.Forms.TextBox InputTextBox;
        private System.Windows.Forms.TextBox OutputTextBox;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem viewToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem standardToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem scientificToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem programmerToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem statisticsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem digitGroupingToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem basicToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem unitConversionToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem dateCalculationToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem worksheetsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem editToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem copyCtrlCToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem pasteCtrlVToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem historyToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem viewHelpF1ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem aboutCalculatorToolStripMenuItem;
        private System.Windows.Forms.Button five;
        private System.Windows.Forms.Button nine;
        private System.Windows.Forms.Button zero;
        private System.Windows.Forms.Button multiply;
        private System.Windows.Forms.Button divide;
    }
}

